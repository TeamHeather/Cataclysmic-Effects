package team.heather.cataclysm.effect.effect.beneficial;

import team.heather.cataclysm.effect.api.callback.AllowCleansingCallback;
import team.heather.cataclysm.effect.effect.CataclysmicMobEffects;

import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_4081;

/**
 * Keeps the affected entity free of harmful mob effects while active. From
 * level II it also puts out fire and removes freezing.
 *
 * <p>Harmful effects are removed from
 * {@link team.heather.cataclysm.effect.mixin.LivingEntityMixin} before vanilla
 * ticks the active effects, as removing them from
 * {@link #method_5572} would break that iteration.</p>
 */
public class CleansingMobEffect extends class_1291 {

    private static final int STATUS_CLEANSING_AMPLIFIER = 1;

    private static final float SOUND_VOLUME = 0.8F;
    private static final float BREW_SOUND_PITCH = 1.6F;
    private static final float EXTINGUISH_SOUND_PITCH = 1.4F;

    public CleansingMobEffect(class_4081 category, int color) {
        super(category, color);
    }

    /**
     * Checks whether Cleansing stops the given effect from reaching the entity.
     *
     * @param entity the entity receiving the effect
     * @param instance the effect about to be applied
     * @return {@code true} if the effect should be rejected
     */
    public static boolean blocks(class_1309 entity, class_1293 instance) {
        return entity.method_6059(CataclysmicMobEffects.CLEANSING) && shouldCleanse(entity, instance);
    }

    /**
     * Removes every harmful effect from the entity if it has Cleansing.
     *
     * @param level the level of the entity
     * @param entity the entity to cleanse
     */
    public static void cleanseEffects(class_3218 level, class_1309 entity) {
        if (!entity.method_6059(CataclysmicMobEffects.CLEANSING)) return;

        boolean cleansed = false;

        for (class_1293 instance : List.copyOf(entity.method_6026())) {
            if (shouldCleanse(entity, instance)) {
                cleansed |= entity.method_6016(instance.method_5579());
            }
        }

        if (cleansed) {
            sendParticles(level, entity);
            level.method_8396(null, entity.method_24515(), class_3417.field_14978, entity.method_5634(), SOUND_VOLUME, BREW_SOUND_PITCH);
        }
    }

    private static boolean shouldCleanse(class_1309 entity, class_1293 instance) {
        return instance.method_5579().comp_349().method_18792() == class_4081.field_18272
                && AllowCleansingCallback.EVENT.invoker().allowCleansing(entity, instance);
    }

    @Override
    public boolean method_5572(class_3218 level, class_1309 entity, int amplifier) {
        if (amplifier < STATUS_CLEANSING_AMPLIFIER) return true;

        boolean burning = entity.method_20802() > 0;

        entity.method_5646();
        entity.method_32317(0);

        if (burning) {
            sendParticles(level, entity);
            level.method_8396(null, entity.method_24515(), class_3417.field_15222, entity.method_5634(), SOUND_VOLUME, EXTINGUISH_SOUND_PITCH);
        }

        return true;
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        return true;
    }

    /**
     * Sends the particles used as visual feedback for Cleansing.
     *
     * @param level the server level in which to send the particles
     * @param entity the cleansed entity
     */
    public static void sendParticles(class_3218 level, class_1309 entity) {
        double y = entity.method_23318() + entity.method_17682() * 0.5D;

        level.method_65096(class_2398.field_11204, entity.method_23317(), y, entity.method_23321(), 6, 0.3D, 0.4D, 0.3D, 0.01D);
    }
}
