package team.heather.cataclysm.effect.effect;

import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import team.heather.cataclysm.effect.CataclysmicEffectsMod;
import team.heather.cataclysm.effect.effect.beneficial.CleansingMobEffect;
import team.heather.cataclysm.effect.effect.beneficial.ImmortalityMobEffect;
import team.heather.cataclysm.effect.effect.harmful.DisperMobEffect;
import team.heather.cataclysm.effect.effect.harmful.MortemMobEffect;
import team.heather.cataclysm.effect.effect.harmful.PaleCorrosionMobEffect;
import team.heather.cataclysm.effect.effect.harmful.VulnerabilityMobEffect;

public final class CataclysmicMobEffects {

    public static final class_6880<class_1291> IMMORTALITY = register("immortality", new ImmortalityMobEffect(class_4081.field_18271, 0xFEFFD1));
    public static final class_6880<class_1291> CLEANSING = register("cleansing", new CleansingMobEffect(class_4081.field_18271, 0xF4F1E6));
    public static final class_6880<class_1291> DISPER = register("disper", new DisperMobEffect(class_4081.field_18272, 0xCE904B));
    public static final class_6880<class_1291> VULNERABILITY = register("vulnerability", new VulnerabilityMobEffect(class_4081.field_18272, 0x9CC4D6));
    public static final class_6880<class_1291> MORTEM = register("mortem", new MortemMobEffect(class_4081.field_18272, 0xC79A3E));
    public static final class_6880<class_1291> PALE_CORROSION = register("pale_corrosion", new PaleCorrosionMobEffect(class_4081.field_18272, 0xD6D3C4));

    private CataclysmicMobEffects() {}

    public static void initialize() {
        CataclysmicEffectsMod.LOGGER.debug("Registered {} effects", 6);
    }

    private static class_6880.class_6883<class_1291> register(String path, class_1291 effect) {
        return class_2378.method_47985(class_7923.field_41174, CataclysmicEffectsMod.createIdentifier(path), effect);
    }
}
