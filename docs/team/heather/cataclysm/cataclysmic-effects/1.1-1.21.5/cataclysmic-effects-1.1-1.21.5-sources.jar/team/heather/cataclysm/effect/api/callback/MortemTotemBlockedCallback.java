package team.heather.cataclysm.effect.api.callback;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

/**
 * Called on the server when Mortem stops a totem from saving an entity. It does
 * not run for entities that die without holding a totem.
 */
@FunctionalInterface
public interface MortemTotemBlockedCallback {

    Event<MortemTotemBlockedCallback> EVENT = EventFactory.createArrayBacked(MortemTotemBlockedCallback.class, callbacks -> (entity, source, totem) -> {
        for (MortemTotemBlockedCallback callback : callbacks) {
            callback.onTotemBlocked(entity, source, totem);
        }
    });

    /**
     * @param entity the entity that will die
     * @param source the source of the lethal damage
     * @param totem the blocked totem, which is not consumed
     */
    void onTotemBlocked(class_1309 entity, class_1282 source, class_1799 totem);
}
