package team.heather.cataclysm.effect.mixin;

import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import team.heather.cataclysm.effect.api.callback.MobEffectTickCallback;

@Mixin(class_1293.class)
public abstract class MobEffectInstanceMixin {

    @Inject(method = "tickServer", at = @At("HEAD"))
    private void cataclysm$onEffectTick(class_3218 level, class_1309 entity, Runnable onUpdate, CallbackInfoReturnable<Boolean> cir) {
        MobEffectTickCallback.EVENT.invoker().onEffectTick(level, entity, (class_1293) (Object) this);
    }
}
