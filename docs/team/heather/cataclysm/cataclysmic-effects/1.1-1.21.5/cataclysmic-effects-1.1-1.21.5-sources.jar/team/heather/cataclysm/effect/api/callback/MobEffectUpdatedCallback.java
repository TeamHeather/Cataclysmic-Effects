package team.heather.cataclysm.effect.api.callback;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;

/**
 * Called on the server after the duration or amplifier of an active mob effect
 * changes because of a refresh, or when it falls back to a hidden effect.
 */
@FunctionalInterface
public interface MobEffectUpdatedCallback {

    Event<MobEffectUpdatedCallback> EVENT = EventFactory.createArrayBacked(MobEffectUpdatedCallback.class, callbacks -> (entity, instance, source) -> {
        for (MobEffectUpdatedCallback callback : callbacks) {
            callback.onEffectUpdated(entity, instance, source);
        }
    });

    /**
     * Creates a callback that only listens to the given effect.
     *
     * @param effect the effect to listen to
     * @param callback the callback to run for that effect
     * @return the filtered callback
     */
    static MobEffectUpdatedCallback only(class_6880<class_1291> effect, MobEffectUpdatedCallback callback) {
        return (entity, instance, source) -> {
            if (instance.method_55654(effect)) {
                callback.onEffectUpdated(entity, instance, source);
            }
        };
    }

    /**
     * @param entity the entity with the effect
     * @param instance the effect in its new state
     * @param source the entity that caused the update, if any
     */
    void onEffectUpdated(class_1309 entity, class_1293 instance, @Nullable class_1297 source);
}
