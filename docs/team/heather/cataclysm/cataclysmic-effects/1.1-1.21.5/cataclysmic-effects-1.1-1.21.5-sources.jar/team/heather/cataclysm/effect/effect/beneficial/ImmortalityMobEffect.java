package team.heather.cataclysm.effect.effect.beneficial;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

public class ImmortalityMobEffect extends class_1291 {

    public ImmortalityMobEffect(class_4081 category, int color) {
        super(category, color);
    }
}