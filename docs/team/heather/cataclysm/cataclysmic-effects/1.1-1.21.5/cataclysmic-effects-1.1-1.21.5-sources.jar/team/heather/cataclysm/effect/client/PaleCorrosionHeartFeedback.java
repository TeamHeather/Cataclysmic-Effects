package team.heather.cataclysm.effect.client;

import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import team.heather.cataclysm.effect.CataclysmicEffectsMod;
import team.heather.cataclysm.effect.effect.harmful.PaleCorrosionMobEffect;

/**
 * Renders the hearts disabled by Pale Corrosion in the health bar. The half
 * sprites cover the right half of a heart, as hearts are disabled from the end
 * of the bar and the left half of that heart may still be alive.
 */
public final class PaleCorrosionHeartFeedback {

    private static final int DURATION = 20;
    private static final int HEART_SIZE = 9;

    private static final class_2960 FULL = CataclysmicEffectsMod.createIdentifier("hud/heart/pale_full");
    private static final class_2960 FULL_BLINKING = CataclysmicEffectsMod.createIdentifier("hud/heart/pale_full_blinking");
    private static final class_2960 HALF = CataclysmicEffectsMod.createIdentifier("hud/heart/pale_half");
    private static final class_2960 HALF_BLINKING = CataclysmicEffectsMod.createIdentifier("hud/heart/pale_half_blinking");

    private static float disabledHealth;
    private static int endTick;

    private PaleCorrosionHeartFeedback() {}

    /**
     * Makes the most recently disabled heart blink when another half is disabled.
     *
     * @param player the player owning the health bar
     */
    public static void update(class_1657 player) {
        float currentDisabledHealth = PaleCorrosionMobEffect.getDisabledHealth(player);

        if (currentDisabledHealth > disabledHealth) {
            endTick = player.field_6012 + DURATION;
        }

        disabledHealth = currentDisabledHealth;
    }

    /**
     * Renders the disabled part of a heart, if any.
     *
     * @param graphics the graphics to render with
     * @param player the player owning the health bar
     * @param slot the index of the heart in the health bar
     * @param x the x position of the heart
     * @param y the y position of the heart
     */
    public static void render(class_332 graphics, class_1657 player, int slot, int x, int y) {
        float disabled = PaleCorrosionMobEffect.getDisabledHealth(player);
        if (disabled <= 0.0F) return;

        int firstDisabled = class_3532.method_15386(player.method_6063());
        int lastDisabled = firstDisabled + class_3532.method_15386(disabled);
        int left = slot * 2;

        boolean full = left >= firstDisabled && left < lastDisabled;
        boolean half = left + 1 == firstDisabled;
        if (!full && !half) return;

        boolean blinking = slot == firstDisabled / 2 && shouldBlink(player);
        class_2960 sprite = full ? (blinking ? FULL_BLINKING : FULL) : (blinking ? HALF_BLINKING : HALF);

        graphics.method_52706(class_1921::method_62277, sprite, x, y, HEART_SIZE, HEART_SIZE);
    }

    private static boolean shouldBlink(class_1657 player) {
        int remainingTicks = endTick - player.field_6012;
        return remainingTicks > 0 && remainingTicks / 3 % 2 == 1;
    }
}
