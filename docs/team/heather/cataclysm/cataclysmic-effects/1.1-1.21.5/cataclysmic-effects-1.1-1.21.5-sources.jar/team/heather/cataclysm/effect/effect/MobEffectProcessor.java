package team.heather.cataclysm.effect.effect;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1291;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import team.heather.cataclysm.effect.effect.harmful.DisperMobEffect;
import team.heather.cataclysm.effect.CataclysmicEffectsMod;

import java.util.function.Consumer;

public final class MobEffectProcessor {
    private MobEffectProcessor() {}

    public static void initialize() {
        CataclysmicEffectsMod.LOGGER.debug("Initializing Mob Effect Processor...");
        registerDisperHandlers();
        CataclysmicEffectsMod.LOGGER.debug("Mob Effect Processor initialized.");
    }

    private static void registerDisperHandlers() {
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) ->
                DisperMobEffect.DISPER_BREAKABLE_BLOCKS.contains(state.method_26204()) || !DisperMobEffect.tryApply(player, pos));

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            class_1799 stack = player.method_5998(hand);

            if (player.method_7325() || !(stack.method_7909() instanceof class_1747)) {
                return class_1269.field_5811;
            }

            class_2338 pos = new class_1750(player, hand, stack, hitResult).method_8037();
            return DisperMobEffect.tryApply(player, pos) ? class_1269.field_5814 : class_1269.field_5811;
        });
    }

    /**
     * Executes the specified task when the player is a server player and has the given effect.
     *
     * @param player the player to check
     * @param effect the mob effect required to execute the task
     * @param task the task to execute with the server player
     * @return {@code true} if the task was executed; otherwise, {@code false}
     */
    public static boolean handle(class_1657 player, class_6880<class_1291> effect, Consumer<class_3222> task) {
        if (player instanceof class_3222 serverPlayer && serverPlayer.method_6059(effect)) {
            task.accept(serverPlayer);
            return true;
        }

        return false;
    }
}