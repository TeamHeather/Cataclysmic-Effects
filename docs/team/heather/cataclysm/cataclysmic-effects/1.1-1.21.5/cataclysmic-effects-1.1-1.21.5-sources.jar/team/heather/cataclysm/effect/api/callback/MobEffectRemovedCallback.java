package team.heather.cataclysm.effect.api.callback;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_6880;

/**
 * Called on the server after a mob effect is removed from an entity.
 *
 * <p>Expired effects are removed while vanilla iterates the active effects, so
 * adding or removing effects here must be deferred to a later tick.</p>
 */
@FunctionalInterface
public interface MobEffectRemovedCallback {

    Event<MobEffectRemovedCallback> EVENT = EventFactory.createArrayBacked(MobEffectRemovedCallback.class, callbacks -> (entity, instance, expired) -> {
        for (MobEffectRemovedCallback callback : callbacks) {
            callback.onEffectRemoved(entity, instance, expired);
        }
    });

    /**
     * Creates a callback that only listens to the given effect.
     *
     * @param effect the effect to listen to
     * @param callback the callback to run for that effect
     * @return the filtered callback
     */
    static MobEffectRemovedCallback only(class_6880<class_1291> effect, MobEffectRemovedCallback callback) {
        return (entity, instance, expired) -> {
            if (instance.method_55654(effect)) {
                callback.onEffectRemoved(entity, instance, expired);
            }
        };
    }

    /**
     * @param entity the entity that lost the effect
     * @param instance the removed effect
     * @param expired {@code true} if the effect ran out of time, {@code false}
     *                if something cleared it, such as milk or a command
     */
    void onEffectRemoved(class_1309 entity, class_1293 instance, boolean expired);
}
