package team.heather.cataclysm.effect.mixin;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import team.heather.cataclysm.effect.api.callback.AllowMobEffectCallback;
import team.heather.cataclysm.effect.api.callback.MobEffectAddedCallback;
import team.heather.cataclysm.effect.api.callback.MobEffectRemovedCallback;
import team.heather.cataclysm.effect.api.callback.MobEffectUpdatedCallback;
import team.heather.cataclysm.effect.effect.CataclysmicMobEffects;
import team.heather.cataclysm.effect.effect.harmful.MortemMobEffect;
import team.heather.cataclysm.effect.effect.harmful.PaleCorrosionMobEffect;
import team.heather.cataclysm.effect.effect.harmful.VulnerabilityMobEffect;

import java.util.Collection;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    @ModifyVariable(method = "hurtServer", at = @At("HEAD"), argsOnly = true)
    private float cataclysm$applyVulnerability(float damage) {
        return VulnerabilityMobEffect.tryApply((class_1309) (Object) this, damage);
    }

    @Inject(method = "checkTotemDeathProtection", at = @At("HEAD"), cancellable = true)
    private void cataclysm$blockTotem(class_1282 source, CallbackInfoReturnable<Boolean> cir) {
        if (MortemMobEffect.blocksTotem((class_1309) (Object) this, source)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "onEffectsRemoved", at = @At("HEAD"))
    private void cataclysm$restorePaleHearts(Collection<class_1293> effects, CallbackInfo ci) {
        for (class_1293 effect : effects) {
            if (effect.method_55654(CataclysmicMobEffects.PALE_CORROSION)) {
                PaleCorrosionMobEffect.restoreHearts((class_1309) (Object) this);
            }
        }
    }

    @Inject(method = "addEffect(Lnet/minecraft/world/effect/MobEffectInstance;Lnet/minecraft/world/entity/Entity;)Z", at = @At("HEAD"), cancellable = true)
    private void cataclysm$allowEffect(class_1293 effect, @Nullable class_1297 source, CallbackInfoReturnable<Boolean> cir) {
        class_1309 entity = (class_1309) (Object) this;

        if (!entity.method_37908().field_9236 && !AllowMobEffectCallback.EVENT.invoker().allowEffect(entity, effect, source)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "onEffectAdded", at = @At("TAIL"))
    private void cataclysm$onEffectAdded(class_1293 effect, @Nullable class_1297 source, CallbackInfo ci) {
        class_1309 entity = (class_1309) (Object) this;

        if (!entity.method_37908().field_9236) {
            MobEffectAddedCallback.EVENT.invoker().onEffectAdded(entity, effect, source);
        }
    }

    @Inject(method = "onEffectUpdated", at = @At("TAIL"))
    private void cataclysm$onEffectUpdated(class_1293 effect, boolean changed, @Nullable class_1297 source, CallbackInfo ci) {
        class_1309 entity = (class_1309) (Object) this;

        // Vanilla also calls this every 30 seconds to resync effects that did not change
        if (changed && !entity.method_37908().field_9236) {
            MobEffectUpdatedCallback.EVENT.invoker().onEffectUpdated(entity, effect, source);
        }
    }

    @Inject(method = "onEffectsRemoved", at = @At("TAIL"))
    private void cataclysm$onEffectsRemoved(Collection<class_1293> effects, CallbackInfo ci) {
        class_1309 entity = (class_1309) (Object) this;
        if (entity.method_37908().field_9236) return;

        for (class_1293 effect : effects) {
            MobEffectRemovedCallback.EVENT.invoker().onEffectRemoved(entity, effect, effect.method_5584() == 0);
        }
    }
}
