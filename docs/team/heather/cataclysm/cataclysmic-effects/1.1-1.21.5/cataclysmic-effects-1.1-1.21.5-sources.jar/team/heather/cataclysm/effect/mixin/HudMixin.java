package team.heather.cataclysm.effect.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1657;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_5134;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import team.heather.cataclysm.effect.client.PaleCorrosionHeartFeedback;
import team.heather.cataclysm.effect.effect.harmful.PaleCorrosionMobEffect;

@Mixin(class_329.class)
public abstract class HudMixin {

    /** Keeps the slots of the hearts disabled by Pale Corrosion in the health bar layout. */
    @ModifyVariable(method = "renderPlayerHealth", at = @At("STORE"), ordinal = 0)
    private float cataclysm$reservePaleHearts(float maxHealth, @Local class_1657 player) {
        PaleCorrosionHeartFeedback.update(player);

        float fullMaxHealth = (float) player.method_45325(class_5134.field_23716) + PaleCorrosionMobEffect.getDisabledHealth(player);
        return Math.max(maxHealth, fullMaxHealth);
    }

    @Inject(
            method = "renderHearts",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/Gui;renderHeart(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/gui/Gui$HeartType;IIZZZ)V",
                    ordinal = 0,
                    shift = At.Shift.AFTER
            )
    )
    private void cataclysm$renderPaleHeart(
            class_332 graphics, class_1657 player, int x, int y, int rowHeight, int regenerationSlot, float maxHealth,
            int health, int displayHealth, int absorption, boolean blinking, CallbackInfo ci,
            @Local(ordinal = 10) int slot, @Local(ordinal = 13) int heartX, @Local(ordinal = 14) int heartY
    ) {
        PaleCorrosionHeartFeedback.render(graphics, player, slot, heartX, heartY);
    }
}
