package team.heather.cataclysm.effect.effect.harmful;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2398;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_4081;
import net.minecraft.class_5134;
import team.heather.cataclysm.effect.CataclysmicEffectsMod;
import team.heather.cataclysm.effect.api.callback.AllowPaleCorrosionCallback;
import team.heather.cataclysm.effect.api.callback.PaleCorrosionHeartDisabledCallback;
import team.heather.cataclysm.effect.api.callback.PaleCorrosionHeartsRestoredCallback;

/**
 * Disables half a heart of the affected entity each time the effect ticks.
 *
 * <p>Hearts are disabled through a max health modifier, so they stay disabled
 * across saves and are synced to the client, which renders them as pale hearts.
 * Like poison, it cannot kill: the last half heart is never disabled.</p>
 *
 * <p>The hearts come back through {@link #restoreHearts(class_1309)} when the
 * effect ends, not through {@link #method_5562}, as vanilla also
 * calls that method whenever the effect is refreshed.</p>
 */
public class PaleCorrosionMobEffect extends class_1291 {

    public static final class_2960 MODIFIER_ID = CataclysmicEffectsMod.createIdentifier("pale_corrosion");

    private static final int BASE_TICK_INTERVAL = 40;
    private static final float DISABLED_HEALTH_PER_TICK = 1.0F;
    private static final float MIN_MAX_HEALTH = 1.0F;

    private static final float SOUND_VOLUME = 0.8F;
    private static final float HURT_SOUND_PITCH = 1.3F;
    private static final float BREAK_SOUND_PITCH = 0.7F;

    public PaleCorrosionMobEffect(class_4081 category, int color) {
        super(category, color);
    }

    @Override
    public boolean method_5572(class_3218 level, class_1309 entity, int amplifier) {
        class_1324 maxHealth = entity.method_5996(class_5134.field_23716);

        if (maxHealth == null || entity.method_6063() - DISABLED_HEALTH_PER_TICK < MIN_MAX_HEALTH
                || !AllowPaleCorrosionCallback.EVENT.invoker().allowCorrosion(entity, amplifier)) {
            return true;
        }

        double disabledHealth = getDisabledHealth(entity) + DISABLED_HEALTH_PER_TICK;

        maxHealth.method_6200(MODIFIER_ID);
        maxHealth.method_26837(new class_1322(MODIFIER_ID, -disabledHealth, class_1322.class_1323.field_6328));

        sendParticles(level, entity);
        playSounds(level, entity);
        PaleCorrosionHeartDisabledCallback.EVENT.invoker().onHeartDisabled(entity, amplifier, (float) disabledHealth);
        return true;
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        int interval = BASE_TICK_INTERVAL >> amplifier;
        return interval <= 0 || duration % interval == 0;
    }

    /**
     * Gets the amount of health currently disabled by Pale Corrosion.
     *
     * @param entity the entity to check
     * @return the disabled health, in half hearts
     */
    public static float getDisabledHealth(class_1309 entity) {
        class_1324 maxHealth = entity.method_5996(class_5134.field_23716);
        class_1322 modifier = maxHealth == null ? null : maxHealth.method_6199(MODIFIER_ID);

        return modifier == null ? 0.0F : (float) -modifier.comp_2449();
    }

    /**
     * Gives back every heart disabled by Pale Corrosion. The hearts return
     * empty, so the entity still has to heal them.
     *
     * @param entity the entity to restore
     */
    public static void restoreHearts(class_1309 entity) {
        class_1324 maxHealth = entity.method_5996(class_5134.field_23716);
        float restoredHealth = getDisabledHealth(entity);

        if (maxHealth != null && maxHealth.method_6200(MODIFIER_ID)) {
            PaleCorrosionHeartsRestoredCallback.EVENT.invoker().onHeartsRestored(entity, restoredHealth);
        }
    }

    /**
     * Sends the particles used as visual feedback for Pale Corrosion.
     *
     * @param level the server level in which to send the particles
     * @param entity the corroded entity
     */
    public static void sendParticles(class_3218 level, class_1309 entity) {
        double x = entity.method_23317();
        double y = entity.method_23318() + entity.method_17682() * 0.6D;
        double z = entity.method_23321();

        level.method_65096(class_2398.field_55169, x, y, z, 3, 0.3D, 0.4D, 0.3D, 0.01D);
        level.method_65096(class_2398.field_23956, x, y, z, 6, 0.35D, 0.45D, 0.35D, 0.02D);
    }

    /**
     * Plays the sounds used as audible feedback for Pale Corrosion.
     *
     * @param level the server level in which to play the sounds
     * @param entity the corroded entity
     */
    public static void playSounds(class_3218 level, class_1309 entity) {
        level.method_8396(null, entity.method_24515(), class_3417.field_54542, entity.method_5634(), SOUND_VOLUME, HURT_SOUND_PITCH);
        level.method_8396(null, entity.method_24515(), class_3417.field_54999, entity.method_5634(), SOUND_VOLUME, BREAK_SOUND_PITCH);
    }
}
