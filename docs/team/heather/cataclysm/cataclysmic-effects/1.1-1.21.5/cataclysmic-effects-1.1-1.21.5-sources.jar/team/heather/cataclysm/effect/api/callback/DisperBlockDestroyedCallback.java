package team.heather.cataclysm.effect.api.callback;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

/**
 * Called on the server after Disper destroys a block.
 */
@FunctionalInterface
public interface DisperBlockDestroyedCallback {

    Event<DisperBlockDestroyedCallback> EVENT = EventFactory.createArrayBacked(DisperBlockDestroyedCallback.class, callbacks -> (player, blockPos, state) -> {
        for (DisperBlockDestroyedCallback callback : callbacks) {
            callback.onBlockDestroyed(player, blockPos, state);
        }
    });

    /**
     * @param player the player with the effect
     * @param blockPos the position of the destroyed block
     * @param state the state of the block before it was destroyed
     */
    void onBlockDestroyed(class_3222 player, class_2338 blockPos, class_2680 state);
}
