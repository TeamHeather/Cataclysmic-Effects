package team.heather.cataclysm.effect.api.callback;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

/**
 * Called on the server when Mortem is about to block a totem. If any listener
 * returns {@code false}, the totem saves the entity as usual.
 */
@FunctionalInterface
public interface AllowMortemTotemBlockCallback {

    Event<AllowMortemTotemBlockCallback> EVENT = EventFactory.createArrayBacked(AllowMortemTotemBlockCallback.class, callbacks -> (entity, source, totem) -> {
        for (AllowMortemTotemBlockCallback callback : callbacks) {
            if (!callback.allowTotemBlock(entity, source, totem)) {
                return false;
            }
        }

        return true;
    });

    /**
     * @param entity the entity about to die
     * @param source the source of the lethal damage
     * @param totem the totem the entity is holding
     * @return {@code true} to let Mortem block the totem
     */
    boolean allowTotemBlock(class_1309 entity, class_1282 source, class_1799 totem);
}
