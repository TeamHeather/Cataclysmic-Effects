package team.heather.cataclysm.effect.client;

import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_3532;

public final class ImmortalityHeartFeedback {

    private static final int DURATION = 20;

    private static UUID playerId;
    private static float damage;
    private static int endTick;

    private ImmortalityHeartFeedback() {}

    public static void show(class_1657 player, float damage) {
        if (damage <= 0.0F) return;

        playerId = player.method_5667();
        ImmortalityHeartFeedback.damage = damage;
        endTick = player.field_6012 + DURATION;
    }

    public static boolean shouldBlink(class_1657 player) {
        if (!isActive(player)) return false;

        int remainingTicks = endTick - player.field_6012;
        return remainingTicks / 3 % 2 == 1;
    }

    public static int getSimulatedHealth(class_1657 player) {
        return class_3532.method_15386(Math.max(player.method_6032() - damage, 0.0F));
    }

    private static boolean isActive(class_1657 player) {
        if (!player.method_5667().equals(playerId) || player.field_6012 >= endTick) {
            playerId = null;
            damage = 0.0F;
            return false;
        }

        return true;
    }
}