package team.heather.cataclysm.effect.payload;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_746;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import team.heather.cataclysm.effect.CataclysmicEffectsMod;
import team.heather.cataclysm.effect.client.ImmortalityHeartFeedback;

public record SuppressedDamagePayload(float damage) implements class_8710 {

    public static final class_9154<SuppressedDamagePayload> PAYLOAD_TYPE = new class_9154<>(CataclysmicEffectsMod.createIdentifier("suppressed_damage"));
    public static final class_9139<class_9129, SuppressedDamagePayload> STREAM_CODEC = class_9139.method_56434(class_9135.field_48552, SuppressedDamagePayload::damage, SuppressedDamagePayload::new);

    public static void initialize() {
        PayloadTypeRegistry.playS2C().register(PAYLOAD_TYPE, STREAM_CODEC);
    }

    @Environment(EnvType.CLIENT)
    public static void initializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(PAYLOAD_TYPE, (payload, context) ->
                context.client().execute(() -> {
                    class_746 player = context.client().field_1724;
                    if (player != null) {
                        ImmortalityHeartFeedback.show(player, payload.damage());
                    }
                })
        );
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PAYLOAD_TYPE;
    }
}