package team.heather.cataclysm.effect.effect.harmful;

import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_4081;
import net.minecraft.class_8103;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;
import team.heather.cataclysm.effect.api.callback.AllowMortemTotemBlockCallback;
import team.heather.cataclysm.effect.api.callback.MortemTotemBlockedCallback;
import team.heather.cataclysm.effect.effect.CataclysmicMobEffects;

/**
 * Prevents affected entities from being saved by any kind of totem.
 *
 * <p>The totem check itself is cancelled in
 * {@link team.heather.cataclysm.effect.mixin.LivingEntityMixin}, which covers
 * every item with the death protection component. While active, two totem
 * particles slowly orbit the entity as an unobtrusive reminder.</p>
 */
public class MortemMobEffect extends class_1291 {

    private static final int PARTICLE_INTERVAL = 8;
    private static final int PARTICLES_PER_ORBIT = 2;
    private static final double ORBIT_RADIUS = 0.6D;
    private static final double ORBIT_HEIGHT = 0.7D;
    private static final float ORBIT_SPEED = 0.05F;
    private static final double PARTICLE_LIFT = 0.1D;

    public MortemMobEffect(class_4081 category, int color) {
        super(category, color);
    }

    /**
     * Checks whether the totem of the given entity should be ignored.
     *
     * @param entity the entity about to die
     * @param source the source of the lethal damage
     * @return {@code true} if the entity has the Mortem effect and a totem would have saved it
     */
    public static boolean blocksTotem(class_1309 entity, class_1282 source) {
        if (!entity.method_6059(CataclysmicMobEffects.MORTEM) || source.method_48789(class_8103.field_42242)) {
            return false;
        }

        class_1799 totem = findTotem(entity);

        if (totem == null || !AllowMortemTotemBlockCallback.EVENT.invoker().allowTotemBlock(entity, source, totem)) {
            return false;
        }

        MortemTotemBlockedCallback.EVENT.invoker().onTotemBlocked(entity, source, totem);
        return true;
    }

    private static @Nullable class_1799 findTotem(class_1309 entity) {
        for (class_1268 hand : class_1268.values()) {
            class_1799 stack = entity.method_5998(hand);

            if (stack.method_57826(class_9334.field_54274)) {
                return stack;
            }
        }

        return null;
    }

    @Override
    public boolean method_5572(class_3218 level, class_1309 entity, int amplifier) {
        class_1293 instance = entity.method_6112(CataclysmicMobEffects.MORTEM);

        if (instance != null && instance.method_5581() && !entity.method_5767()) {
            sendParticles(level, entity);
        }

        return true;
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        return duration % PARTICLE_INTERVAL == 0;
    }

    /**
     * Sends the particles used as visual feedback for Mortem.
     *
     * @param level the server level in which to send the particles
     * @param entity the entity the particles orbit around
     */
    public static void sendParticles(class_3218 level, class_1309 entity) {
        float angle = entity.field_6012 * ORBIT_SPEED;
        double y = entity.method_23318() + entity.method_17682() * ORBIT_HEIGHT;

        for (int i = 0; i < PARTICLES_PER_ORBIT; i++) {
            float particleAngle = angle + i * class_3532.field_29846 / PARTICLES_PER_ORBIT;
            double x = entity.method_23317() + class_3532.method_15362(particleAngle) * ORBIT_RADIUS;
            double z = entity.method_23321() + class_3532.method_15374(particleAngle) * ORBIT_RADIUS;

            // A count of 0 uses the offset as the velocity of a single particle
            level.method_65096(class_2398.field_11220, x, y, z, 0, 0.0D, PARTICLE_LIFT, 0.0D, 1.0D);
        }
    }
}
