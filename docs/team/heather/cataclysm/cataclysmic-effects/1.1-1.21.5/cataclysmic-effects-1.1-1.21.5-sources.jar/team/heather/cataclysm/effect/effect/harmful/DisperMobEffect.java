package team.heather.cataclysm.effect.effect.harmful;

import team.heather.cataclysm.effect.api.callback.AllowDisperCallback;
import team.heather.cataclysm.effect.api.callback.DisperBlockDestroyedCallback;
import team.heather.cataclysm.effect.effect.CataclysmicMobEffects;
import team.heather.cataclysm.effect.effect.MobEffectProcessor;

import java.util.Set;
import net.minecraft.class_1291;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4081;

/**
 * Prevents affected players from interacting with most blocks.
 *
 * <p>When the Disper functionality is applied, the targeted block is destroyed
 * with its normal drops, followed by particles and sounds at its position.
 * Blocks listed in {@link #DISPER_BREAKABLE_BLOCKS} are expected to be excluded
 * by the event handler before calling {@link #tryApply(class_1657, class_2338)}.</p>
 */
public class DisperMobEffect extends class_1291 {

    /**
     * Blocks that players affected by Disper may break normally.
     */
    public static final Set<class_2248> DISPER_BREAKABLE_BLOCKS = Set.of(class_2246.field_10260, class_2246.field_54717);

    public DisperMobEffect(class_4081 category, int color) {
        super(category, color);
    }

    /**
     * Applies the Disper functionality if the player has the Disper effect.
     *
     * <p>The targeted block is destroyed with its normal loot drops before the
     * Disper particles and sounds are emitted. No action is performed when the
     * player is not a server player or does not have the effect.</p>
     *
     * @param player the player whose effects are checked
     * @param blockPos the targeted block position
     * @return {@code true} if the player had Disper and the functionality ran;
     *         otherwise, {@code false}
     */
    public static boolean tryApply(class_1657 player, class_2338 blockPos) {
        if (player instanceof class_3222 serverPlayer && serverPlayer.method_6059(CataclysmicMobEffects.DISPER)
                && !AllowDisperCallback.EVENT.invoker().allowDisper(serverPlayer, blockPos)) {
            return false;
        }

        return MobEffectProcessor.handle(player, CataclysmicMobEffects.DISPER, serverPlayer -> {
            class_3218 level = serverPlayer.method_51469();
            class_2680 state = level.method_8320(blockPos);

            level.method_8651(blockPos, true, serverPlayer);
            sendParticles(level, blockPos);
            playSounds(level, blockPos);
            DisperBlockDestroyedCallback.EVENT.invoker().onBlockDestroyed(serverPlayer, blockPos, state);
        });
    }

    /**
     * Sends the particles used as visual feedback for Disper.
     *
     * @param level the server level in which to send the particles
     * @param blockPos the center position of the particle effect
     */
    public static void sendParticles(class_3218 level, class_2338 blockPos) {
        double x = blockPos.method_10263() + 0.5D;
        double y = blockPos.method_10264() + 0.5D;
        double z = blockPos.method_10260() + 0.5D;

        level.method_65096(class_2398.field_29642, x, y, z, 4, 0.35D, 0.35D, 0.35D, 0.05D);
        level.method_65096(class_2398.field_11251, x, y, z, 8, 0.25D, 0.25D, 0.25D, 0.01D);
    }

    /**
     * Plays the sounds used as audible feedback for Disper.
     *
     * @param level the server level in which to play the sounds
     * @param blockPos the source position of the sounds
     */
    public static void playSounds(class_3218 level, class_2338 blockPos) {
        level.method_8396(null, blockPos, class_3417.field_14979, class_3419.field_15245, 0.8F, 1.75F);
        level.method_8396(null, blockPos, class_3417.field_14979, class_3419.field_15245, 0.8F, 1.85F);
    }
}