package team.heather.cataclysm.effect.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import team.heather.cataclysm.effect.effect.CataclysmicMobEffects;
import team.heather.cataclysm.effect.effect.harmful.MortemMobEffect;
import team.heather.cataclysm.effect.effect.harmful.PaleCorrosionMobEffect;
import team.heather.cataclysm.effect.effect.harmful.VulnerabilityMobEffect;

import java.util.Collection;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1309;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    @ModifyVariable(method = "hurtServer", at = @At("HEAD"), argsOnly = true)
    private float cataclysm$applyVulnerability(float damage) {
        return VulnerabilityMobEffect.tryApply((class_1309) (Object) this, damage);
    }

    @Inject(method = "checkTotemDeathProtection", at = @At("HEAD"), cancellable = true)
    private void cataclysm$blockTotem(class_1282 source, CallbackInfoReturnable<Boolean> cir) {
        if (MortemMobEffect.blocksTotem((class_1309) (Object) this)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "onEffectsRemoved", at = @At("HEAD"))
    private void cataclysm$restorePaleHearts(Collection<class_1293> effects, CallbackInfo ci) {
        for (class_1293 effect : effects) {
            if (effect.method_55654(CataclysmicMobEffects.PALE_CORROSION)) {
                PaleCorrosionMobEffect.restoreHearts((class_1309) (Object) this);
            }
        }
    }
}
